<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Регистрация</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="css/registration.css">
</head>
<body>


<div class="header">
    <div class="header_section">
        <div class="header_item headerlogo"  >
        Стоматологическая клиника DentaPlus
        </div> 
        <div class="header_item headerButton"><a href="/" style="color: white">Главная</a></div>
        <div class="header_item headerButton"><a href="/doctors.php" style="color: white">Вернуться назад</a></div>
    </div>
</div>

<div class="container">
 
  <form action="/check.php" method="POST"> <img  src="img/3294767.png">
  <h1>Регистрация нового пользователя</h1>
    <div class="input-form">
    
      <input type="text" name="name" placeholder="Введите ФИО">
    </div>
    <div class="input-form">
      <input type="password" name="password" placeholder="Введите пароль">
    </div>
    <div class="input-form">
      <input type="text" name="phone" placeholder="Введите номер телефона">
    </div>
    <div class="input-form">
      <input type="text" name="birth_date" placeholder="Введите дату рождения">
    </div>
    <input class="bick" type="submit" name="submit" value="Зарегистрироваться"><br />
  </form>
</div>



</body>
</html>