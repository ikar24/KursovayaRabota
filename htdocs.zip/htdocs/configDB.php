<?php
  $dsn = 'mysql:host=localhost;dbname=stom';
  $pdo = new PDO($dsn, 'root', 'root');
?>
