<!DOCTYPE html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Добавление смены</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="css/add_doctor.css">
</head>

<body>

<div class="header">
    <div class="header_section">
        <div class="header_item headerlogo"  >
        Стоматологическая клиника DentaPlus
        </div> 
        <div class="header_item headerButton"><a href="/" style="color: white">Главная</a></div>
        <div class="header_item headerButton"><a href="/shifts.php" style="color: white">Вернуться назад</a></div>
    </div>
</div>

<div class="container">
		<form action="/check_shift.php" method="POST"><img src="img/2827775.png">
			<div class="input-form">
              <input type="text" name="date" placeholder="Введите дату">
            </div>
      <div class="input-form">
              <input type="text" name="name" placeholder="Введите ФИО врача">
            </div>
			<div class="input-form">
              <input type="text" name="start" placeholder="Введите начало смены">
            </div>
      <div class="input-form">
              <input type="text" name="finish" placeholder="Введите конец смены">
            </div>
            <input class="bick" type="submit" name="submit" value="Добавить смену">
            <br />
		</form>
</div>

</body>
</html>