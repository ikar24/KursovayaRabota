<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Список смен</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="css//session.css">
</head>
<body>

<div class="header">
    <div class="header_section">
        <div class="header_item headerlogo"  >
        Стоматологическая клиника DentaPlus
        </div> 
        <div class="header_item headerButton"><a href="/" style="color: white">Главная</a></div>
        <div class="header_item headerButton"><a href="/" style="color: white">Вернуться назад</a></div>
    </div>
</div>

<div class="container">
		<form action="/shifts.php" method="POST">
    <div class="input-form">
            			<div class="input-form">
              <input type="text" name="name" placeholder="Выберите врача">
            </div>
            <input class="bick" type="submit" name="submit" value="Показать список"><br />
		</form>
</div>


<?php
require 'configDB.php';

$name = filter_var(trim($_POST['name']),
FILTER_SANITIZE_STRING);

echo '<table class="table table-bordered">
 <thead>
 <tr>
 <th>Дата:</th>
 <th>Начало смены:</th>
 <th>Конец смены: </th>
 <th></th>
 </tr>
 </thead>
 <tbody>';

 $query1 = $pdo->query("SELECT * FROM `doctors` WHERE `name`='$name'");
 $row1 = $query1->fetch(PDO::FETCH_OBJ);
 
 $query2 = $pdo->query("SELECT * FROM `shifts` WHERE `doctor_id`='$row1->doctor_id' ORDER BY `date` ASC");
 while($row2 = $query2->fetch(PDO::FETCH_OBJ))
 {
  $a=explode(' ',$row2->start);
  $b=explode(' ',$row2->finish);
     echo' <tr>
     <td>'.$row2->date.'</td>
     <td>'.$a[1].'</td>
     <td>'.$b[1].'</td>';
     echo '<td><div class="but"><a href="delete_shift.php?id='.$row2->shift_id.'"<button class="gradient-button">Удалить</button></a></div></td>';
     echo '</tr>';
    }
     echo ' </tbody>
     </table>';



?>

<div class="hai" style="color:white">Здравствуйте, <?=$_COOKIE['admin']?></div>
  <a class="buttons" href="/add_shift.php">Добавить смену</a>
  <a class="buttons" href="/exit.php">Выход</a>

</div>
</body>
</html>