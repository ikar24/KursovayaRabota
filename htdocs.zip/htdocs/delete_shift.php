<?php 
require 'configDB.php';
$id = $_GET['id'];
$query1 = $pdo->query("DELETE FROM `shifts` WHERE `shift_id`= '$id'");

header('Location: /shifts.php');
?>
