<?php
 require 'configDB.php';

 $name = filter_var(trim($_POST['name']),
 FILTER_SANITIZE_STRING);
 $date = filter_var(trim($_POST['date']),
 FILTER_SANITIZE_STRING);
 $time1 = filter_var(trim($_POST['start']),
 FILTER_SANITIZE_STRING);
 $time2 = filter_var(trim($_POST['finish']),
 FILTER_SANITIZE_STRING);
 $start = $date." ".$time1;
 $finish = $date." ".$time2;
 
 $query1 = $pdo->query("SELECT * FROM `doctors` WHERE `name`='$name'");
 $row1 = $query1->fetch(PDO::FETCH_OBJ);
 $doctor_id=$row1->doctor_id;
//  if(mb_strlen($password)<4 || mb_strlen($password)>16)
//  {
//      echo "Длина пароля недопустима(от 4 до 16)";
// exit();
//  }
//  else if(mb_strlen($phone)!=11)
//  {
//      echo "Некоректный телефон";
// exit();
// }
require 'configDB.php';
$query = $pdo->query("INSERT INTO `shifts` (`doctor_id`, `date`, `start`, `finish`) 
VALUES('$doctor_id','$date','$start','$finish')");
  
header('Location: /shifts.php');
?>