<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Список врачей</title>
  <link rel="stylesheet" href="css/doctors.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="header">
    <div class="header_section">
        <div class="header_item headerlogo"  >
        Стоматологическая клиника DentaPlus
        </div> 
        <div class="header_item headerButton"><a href="/" style="color: white">Главная</a></div>
        <div class="header_item headerButton"><a href="/index.php" style="color: white">Вернуться назад</a></div>
    </div>
</div>
  <div class="container">
    <h1>Список врачей</h1>
<?php
require 'configDB.php';



echo '<table class="table table-bordered">
<thead>
<tr>
<th>Имя врача:</th>
<th>Специализация: </th>
<th></th>
</tr>
</thead>
<tbody>';


$query1 = $pdo->query("SELECT * FROM `doctors`");
while($row1 = $query1->fetch(PDO::FETCH_OBJ)){
  if($row1->active==1)
  {
    echo' <tr>
    <td>'.$row1->name.'</td>
    <td>'.$row1->specialization.'</td>';
    echo '<td><div class="but"><a href="delete_doctor.php?id='.$row1->doctor_id.'"<button class="buttons">Удалить</button></a></div></td>';
    echo '</tr>';}
  }
  echo ' </tbody>
  </table>';

?>
  <div class="hai" style="color:white">Здравствуйте,  <?=$_COOKIE['admin']?>!</div>
  <a class="buttons" href="/add_doctor.php">Добавить врача</a>
  <a class="buttons" href="/exit.php">Выход</a>
</div>
</body>
</html>




