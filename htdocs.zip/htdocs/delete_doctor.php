<?php 
require 'configDB.php';
$id = $_GET['id'];
$query1 = $pdo->query("UPDATE `doctors` SET `active`='0' WHERE `doctor_id`= '$id'");

header('Location: /doctors.php');
?>
